package mobi.garden.bottomnavigationtest.Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Rating extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
