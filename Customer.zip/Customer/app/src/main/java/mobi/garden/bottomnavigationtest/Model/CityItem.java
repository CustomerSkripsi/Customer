package mobi.garden.bottomnavigationtest.Model;

public class CityItem {
    private String namaKota;

    public CityItem(String namaKota) {
        this.namaKota = namaKota;
    }

    public void setNamaKota(String namaKota) {
        this.namaKota = namaKota;
    }

    public String getNamaKota() {
        return namaKota;
    }
}
