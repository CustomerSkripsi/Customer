package mobi.garden.bottomnavigationtest.LoginRegister;

public interface GetUserCallBack {
    public abstract void done(User returnedUser);
}
