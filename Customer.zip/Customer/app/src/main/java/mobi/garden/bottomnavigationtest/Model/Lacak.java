package mobi.garden.bottomnavigationtest.Model;

public class Lacak {

    private String orderID, tanggal, statusOrder, alamat, phone, outletName, statusOrderID, lacakdetail, orderProductQty;
    private int  totalHarga;


    public String getStatusOrderID() {
        return statusOrderID;
    }

    public void setStatusOrderID(String statusOrderID) {
        this.statusOrderID = statusOrderID;
    }

    public String getOutletName() {
        return outletName;
    }

    public void setOutletName(String outletName) {
        this.outletName = outletName;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getStatusOrder() {
        return statusOrder;
    }

    public void setStatusOrder(String statusOrder) {
        this.statusOrder = statusOrder;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getLacakDetail() {
        return lacakdetail;
    }

    public int getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(int totalHarga) {
        this.totalHarga = totalHarga;
    }

}
